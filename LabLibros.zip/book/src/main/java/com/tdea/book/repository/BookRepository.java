package com.tdea.book.repository;

import com.tdea.book.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    // Busqueda parcial por nombre (LIKE), sin distinguir mayusculas/minusculas
    List<Book> findByNameContainingIgnoreCase(String name);
}
