import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BookList from "./components/BookList";
import BookForm from "./components/BookForm";

function App() {
  const [searchInput, setSearchInput] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);
  const [editingBook, setEditingBook] = useState(null);

  const refresh = () => setRefreshKey((k) => k + 1);

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchTerm(searchInput);
  };

  const handleClear = () => {
    setSearchInput("");
    setSearchTerm("");
  };

  const handleSaved = () => {
    setEditingBook(null);
    refresh();
  };

  return (
    <div className="container py-4">
      <h1 className="fw-bold mb-4">📚 Catalogue Management System</h1>

      <form className="d-flex gap-2 mb-4" onSubmit={handleSearch}>
        <input
          className="form-control form-control-sm w-auto"
          placeholder="Search by name"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
        />
        <button type="submit" className="btn btn-primary btn-sm">
          Search
        </button>
        <button
          type="button"
          className="btn btn-outline-secondary btn-sm"
          onClick={handleClear}
        >
          Clear
        </button>
      </form>

      <h5 className="fw-bold">{editingBook ? "Edit Book" : "Add Book"}</h5>
      <BookForm
        editingBook={editingBook}
        onSaved={handleSaved}
        onCancel={() => setEditingBook(null)}
      />

      <div className="card shadow-sm mt-4">
        <div className="card-body">
          <h4 className="fw-bold mb-3">📚 Book Catalogue</h4>
          <BookList
            searchTerm={searchTerm}
            refreshKey={refreshKey}
            onEdit={setEditingBook}
            onChanged={refresh}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
