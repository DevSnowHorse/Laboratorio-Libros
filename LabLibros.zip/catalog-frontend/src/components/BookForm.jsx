import { useEffect, useState } from "react";
import BookService from "../services/BookService";

const emptyBook = {
  name: "",
  isbnNumber: "",
  author: "",
  publishDate: "",
  price: "",
  type: "HARDCOVER",
};

function BookForm({ editingBook, onSaved, onCancel }) {
  const [book, setBook] = useState(emptyBook);

  // Si se pulsa "Edit" en la tabla, el formulario se llena con ese libro
  useEffect(() => {
    setBook(editingBook ? { ...editingBook } : emptyBook);
  }, [editingBook]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBook((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const payload = { ...book, price: Number(book.price) };
    const request = editingBook
      ? BookService.update(editingBook.id, payload)
      : BookService.create(payload);

    request
      .then(() => {
        alert(
          editingBook
            ? "Libro actualizado correctamente"
            : "Libro creado correctamente"
        );
        setBook(emptyBook);
        onSaved();
      })
      .catch(() => alert("No se pudo guardar el libro"));
  };

  return (
    <form className="d-flex flex-wrap gap-2" onSubmit={handleSubmit}>
      <input
        className="form-control form-control-sm w-auto"
        name="name"
        placeholder="Book Name"
        value={book.name || ""}
        onChange={handleChange}
        required
      />
      <input
        className="form-control form-control-sm w-auto"
        name="isbnNumber"
        placeholder="ISBN"
        value={book.isbnNumber || ""}
        onChange={handleChange}
        required
      />
      <input
        className="form-control form-control-sm w-auto"
        name="author"
        placeholder="Author"
        value={book.author || ""}
        onChange={handleChange}
        required
      />
      <input
        className="form-control form-control-sm w-auto"
        type="date"
        name="publishDate"
        value={book.publishDate || ""}
        onChange={handleChange}
        required
      />
      <input
        className="form-control form-control-sm w-auto"
        type="number"
        step="0.01"
        min="0"
        name="price"
        placeholder="Price"
        value={book.price ?? ""}
        onChange={handleChange}
        required
      />
      <select
        className="form-select form-select-sm w-auto"
        name="type"
        value={book.type || "HARDCOVER"}
        onChange={handleChange}
      >
        <option value="EBOOK">EBOOK</option>
        <option value="SOFTCOPY">SOFTCOPY</option>
        <option value="HARDCOVER">HARDCOVER</option>
      </select>

      <button type="submit" className="btn btn-primary btn-sm">
        {editingBook ? "Update Book" : "Add Book"}
      </button>
      {editingBook && (
        <button
          type="button"
          className="btn btn-secondary btn-sm"
          onClick={onCancel}
        >
          Cancel
        </button>
      )}
    </form>
  );
}

export default BookForm;
