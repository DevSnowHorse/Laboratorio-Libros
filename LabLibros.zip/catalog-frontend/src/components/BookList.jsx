import { useEffect, useState } from "react";
import BookService from "../services/BookService";

function BookList({ searchTerm, refreshKey, onEdit, onChanged }) {
  const [books, setBooks] = useState([]);
  const [error, setError] = useState("");

  // Carga la lista al abrir la pagina, al buscar y cada vez que cambia refreshKey
  useEffect(() => {
    const term = searchTerm.trim();
    const request = term ? BookService.search(term) : BookService.getAll();

    request
      .then((res) => {
        // /search responde 204 (sin cuerpo) cuando no hay coincidencias
        setBooks(res.status === 204 || !Array.isArray(res.data) ? [] : res.data);
        setError("");
      })
      .catch(() =>
        setError("No se pudo conectar con el backend (http://localhost:8080).")
      );
  }, [searchTerm, refreshKey]);

  const handleDelete = (book) => {
    if (!window.confirm(`¿Eliminar el libro "${book.name}"?`)) return;

    BookService.delete(book.id)
      .then(() => {
        alert("Libro eliminado correctamente");
        onChanged();
      })
      .catch(() => alert("No se pudo eliminar el libro"));
  };

  return (
    <>
      {error && <div className="alert alert-danger">{error}</div>}

      <table className="table table-bordered table-hover align-middle">
        <thead>
          <tr className="text-center">
            {["ID", "Name", "ISBN", "Author", "Publish Date", "Price", "Type", "Actions"].map(
              (title) => (
                <th key={title} className="bg-primary text-white">
                  {title}
                </th>
              )
            )}
          </tr>
        </thead>
        <tbody>
          {books.length === 0 ? (
            <tr>
              <td colSpan="8" className="text-center text-muted">
                No hay libros para mostrar
              </td>
            </tr>
          ) : (
            books.map((book) => (
              <tr key={book.id}>
                <td>{book.id}</td>
                <td>{book.name}</td>
                <td>{book.isbnNumber}</td>
                <td>{book.author}</td>
                <td>{book.publishDate}</td>
                <td>{book.price}</td>
                <td>{book.type}</td>
                <td className="text-center">
                  <button
                    className="btn btn-primary btn-sm me-1"
                    onClick={() => onEdit(book)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => handleDelete(book)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </>
  );
}

export default BookList;
