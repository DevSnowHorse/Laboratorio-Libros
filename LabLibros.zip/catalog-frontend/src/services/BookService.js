import axios from "axios";

const API_URL = "http://localhost:8080/api/books";

class BookService {
  getAll() {
    return axios.get(API_URL);
  }

  getById(id) {
    return axios.get(`${API_URL}/${id}`);
  }

  search(name) {
    return axios.get(`${API_URL}/search`, { params: { name } });
  }

  create(book) {
    return axios.post(API_URL, book);
  }

  update(id, book) {
    return axios.put(`${API_URL}/${id}`, book);
  }

  delete(id) {
    return axios.delete(`${API_URL}/${id}`);
  }
}

export default new BookService();
